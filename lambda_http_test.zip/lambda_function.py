import time
import requests

def lambda_handler(event, context):
    start = time.time()
    urls = ["https://httpbin.org/get"] * 10
    for url in urls:
        _ = requests.get(url)
    end = time.time()

    return {
        "requests": len(urls),
        "time_sec": round(end - start, 4)
    }
